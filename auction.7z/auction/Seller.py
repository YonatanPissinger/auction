class Seller:

    seller_data = {
        "product": input("Enter your product's type please: "),
        "color": input("Enter your product's color please: "),
    }